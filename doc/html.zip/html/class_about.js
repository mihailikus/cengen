var class_about =
[
    [ "About", "class_about.html#a3c6fd8fbc97d4cf92ab04f3335ddb455", null ],
    [ "~About", "class_about.html#ac12f630b606ab520515e7a44c2144112", null ],
    [ "addThanks", "class_about.html#abc0ed9bdad9e1acb44537a218850769e", null ],
    [ "setAuthor", "class_about.html#aba3d758b7696587d4f89c82541c99648", null ],
    [ "setAuthorPhoto", "class_about.html#aa1212f1784d285c68f4c928dbb28f4d6", null ],
    [ "setLicense", "class_about.html#ac49bccbf3e886ad2f30b8681ad5f387c", null ],
    [ "setLicenseText", "class_about.html#ad8584093c570bf210e1263f8846d0d28", null ],
    [ "setMail", "class_about.html#a1ba170f3e62deaef4458c2170cb5a186", null ],
    [ "setPhone", "class_about.html#ac55c582b7f1d5eb383fe30c1ce5ca583", null ],
    [ "setSite", "class_about.html#accd8e81c5bcf263e9529da44cc7c8c72", null ]
];