var class_add_line_master =
[
    [ "AddLineMaster", "class_add_line_master.html#ac19beddfea66a58b1d7eec1cb3bf2372", null ],
    [ "~AddLineMaster", "class_add_line_master.html#ab5773cb06b6e2b821f7e610633c7e859", null ],
    [ "set_line_number", "class_add_line_master.html#a8f90611b16534d32ecdf93dd45601996", null ],
    [ "set_values", "class_add_line_master.html#a7b703800ea62c18154a7eabd07331a9f", null ],
    [ "update_preview", "class_add_line_master.html#a312a39e8f1c19fc7d86c476267e559cb", null ],
    [ "values_changed", "class_add_line_master.html#ab9dbcd03d215f1a4e1821bb06240fdf3", null ]
];