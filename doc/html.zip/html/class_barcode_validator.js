var class_barcode_validator =
[
    [ "BarcodeValidator", "class_barcode_validator.html#a82cba76cfd384e99f23cb7549be0e191", null ],
    [ "validate", "class_barcode_validator.html#ada91b0d9248d4d629403e6540fe29e7b", null ]
];