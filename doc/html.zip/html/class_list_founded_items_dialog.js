var class_list_founded_items_dialog =
[
    [ "ListFoundedItemsDialog", "class_list_founded_items_dialog.html#af851caf3277e1c9e61aa1630234e7f70", null ],
    [ "setMessage", "class_list_founded_items_dialog.html#a8988652c7bd10f2a88994c7f6ba29f1c", null ],
    [ "setMessage", "class_list_founded_items_dialog.html#aeeb920e8513f573e50693ffb5b45c822", null ]
];