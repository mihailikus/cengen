var class_sql_config =
[
    [ "dbHost", "class_sql_config.html#ac63f4e3f60e9a02d638f68257a5f6d29", null ],
    [ "dbName", "class_sql_config.html#adb6d3fcaff54e63b633a61e1c1a84a2a", null ],
    [ "dbPass", "class_sql_config.html#ac3d95a1258fd59ca1c7479d53ff2bbf5", null ],
    [ "dbUser", "class_sql_config.html#a52baca84b275b6b60dc97b1dcba49398", null ],
    [ "tbName", "class_sql_config.html#a2d52c46d3a6d615f9ff4714905257953", null ]
];