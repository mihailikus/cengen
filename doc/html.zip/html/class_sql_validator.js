var class_sql_validator =
[
    [ "SqlValidator", "class_sql_validator.html#afdc45ef477fcb8455ec6f65d9da25e75", null ],
    [ "validate", "class_sql_validator.html#a584ff45d7f9bfe11d8b7aa5ebc5bfdc5", null ]
];