var class_ui___dialog =
[
    [ "retranslateUi", "class_ui___dialog.html#afa0ccb6f716ca6178260522a193c250e", null ],
    [ "setupUi", "class_ui___dialog.html#a4f6a478c3ecdafabffb17b39cb26444a", null ],
    [ "buttonBox", "class_ui___dialog.html#a271a59402f80983c2722bb455db37365", null ],
    [ "graphicsView", "class_ui___dialog.html#a95e25d36a940c3e3e4a684c7dea1dece", null ],
    [ "gridLayout", "class_ui___dialog.html#a41336d41594e8776a81d095e8e4ffc61", null ],
    [ "gridLayoutWidget", "class_ui___dialog.html#af56f0c59b650c50a635d4b11890c172e", null ],
    [ "heithSpin", "class_ui___dialog.html#af1ef38c02e0bc59838d06cbce6a4b5b2", null ],
    [ "label", "class_ui___dialog.html#ac3844fd0281707dc5535826da7506ca5", null ],
    [ "label_2", "class_ui___dialog.html#acfbb1773ba7dc7aa425b0b3b8981686a", null ],
    [ "label_3", "class_ui___dialog.html#a3bb3c83086d124c6e85906f15c8add64", null ],
    [ "label_4", "class_ui___dialog.html#a0f20bebec836535dc4cfcc33647dd2aa", null ],
    [ "label_5", "class_ui___dialog.html#a640f65059bf215b0096f894e7ace21e3", null ],
    [ "label_6", "class_ui___dialog.html#a30b8516534f30c4241a55e3fb9dcd766", null ],
    [ "startXspin", "class_ui___dialog.html#a5f086aee3984b8e6944d3b83a8429777", null ],
    [ "startYspin", "class_ui___dialog.html#a108781ef52a950ce285441166bfd3eee", null ],
    [ "thickSpin", "class_ui___dialog.html#aed5c39f3e503e2d3e743d89c6aa60738", null ],
    [ "widthSpin", "class_ui___dialog.html#a87dc72e4aa6e0c2fdd7680157751771a", null ]
];