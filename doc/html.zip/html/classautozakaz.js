var classautozakaz =
[
    [ "autozakaz", "classautozakaz.html#af6a87b484ef79525d46dcf68806d24c8", null ],
    [ "~autozakaz", "classautozakaz.html#a28f76f291a26f624e36248351c3deee0", null ],
    [ "get_config", "classautozakaz.html#a1dde87c2931f264d1744e721a4ce7028", null ],
    [ "get_days_for_zakaz", "classautozakaz.html#abc2bd66f3e61d986eed87b5e1306c0e7", null ],
    [ "set_config", "classautozakaz.html#a57c7e69d933b415d7a0c47ad02ef48a8", null ]
];