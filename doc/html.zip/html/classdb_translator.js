var classdb_translator =
[
    [ "tbarcode", "classdb_translator.html#a8b3ec24ea694212a4e209fc25fecc5ad", null ],
    [ "tname", "classdb_translator.html#af3da0f148d1c96186f7a729992ae6aed", null ],
    [ "tnomer", "classdb_translator.html#a35e990e643c58a86cbf4740f73fb6f20", null ],
    [ "tprice", "classdb_translator.html#a2cdaf4360199fdd7902a19d694eb1840", null ]
];