var classdbf__informer =
[
    [ "dbf_informer", "classdbf__informer.html#a108df4eecb2a2189ef548b97f3ebdccb", null ],
    [ "~dbf_informer", "classdbf__informer.html#a728f7d33e6a1a270137393c4c1a110f3", null ],
    [ "file_is_ready", "classdbf__informer.html#a3d134ff2360a3805d4d2fe5abb16fa12", null ],
    [ "found_by_tnomer", "classdbf__informer.html#a2b4778d6aed4d9180b4143eb44afbea5", null ],
    [ "found_record_in_dbf", "classdbf__informer.html#acc9c00792f055b450b34941c24d01755", null ],
    [ "get_dbf_header", "classdbf__informer.html#ae2e05b62e6891c619329dffcd526622c", null ],
    [ "last_found_record", "classdbf__informer.html#acfeaf3fc3469577f5ebad2541adf935f", null ],
    [ "dbf_fields", "classdbf__informer.html#abe97d4f6879c2b8e7c2e961a691c2088", null ]
];