var classeditor =
[
    [ "editor", "classeditor.html#a1a6d65252613816a70dc1a18ed9a3c60", null ],
    [ "~editor", "classeditor.html#a7e5f0876161f480ecfce990013b9c048", null ],
    [ "get_new_fileName", "classeditor.html#a76582bfc5e00deed3a9f3337d5941513", null ],
    [ "get_new_shablon", "classeditor.html#a4a81e279f5ddd2ff1ec201c19de06d60", null ],
    [ "load_xml_data_into_editor", "classeditor.html#aebfa77945700e8331f5b40a595a620f2", null ],
    [ "set_file_name", "classeditor.html#a6c67a9289ba67348464a9ca9e9e19887", null ]
];