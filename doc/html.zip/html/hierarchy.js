var hierarchy =
[
    [ "About", "class_about.html", null ],
    [ "AddLineMaster", "class_add_line_master.html", null ],
    [ "autozakaz", "classautozakaz.html", null ],
    [ "autozakaz_config", "structautozakaz__config.html", null ],
    [ "BarcodeValidator", "class_barcode_validator.html", null ],
    [ "dbf_field_descr", "structdbf__field__descr.html", null ],
    [ "dbf_informer::dbf_one_field", "structdbf__informer_1_1dbf__one__field.html", null ],
    [ "DbfConfig", "class_dbf_config.html", null ],
    [ "dbfHeader", "structdbf_header.html", [
      [ "dbf_informer", "classdbf__informer.html", null ]
    ] ],
    [ "dbTranslator", "classdb_translator.html", null ],
    [ "editor", "classeditor.html", null ],
    [ "ImageBox", "class_image_box.html", [
      [ "Barcode", "class_barcode.html", null ],
      [ "cengen", "classcengen.html", null ],
      [ "Cennic", "class_cennic.html", null ]
    ] ],
    [ "ListFoundedItemsDialog", "class_list_founded_items_dialog.html", null ],
    [ "MainTableWidget", "class_main_table_widget.html", null ],
    [ "SellFilterWidget", "class_sell_filter_widget.html", null ],
    [ "SqlConfig", "class_sql_config.html", null ],
    [ "SqlValidator", "class_sql_validator.html", null ],
    [ "cengen::TabsOrder", "structcengen_1_1_tabs_order.html", null ],
    [ "Tinformer", "class_tinformer.html", null ],
    [ "TNValidator", "class_t_n_validator.html", null ],
    [ "Tovar", "struct_tovar.html", null ],
    [ "Ui_Dialog", "class_ui___dialog.html", [
      [ "Ui::Dialog", "class_ui_1_1_dialog.html", null ]
    ] ]
];