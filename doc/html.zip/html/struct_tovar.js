var struct_tovar =
[
    [ "operator<", "struct_tovar.html#ad566921c830e3919dda043641fc85f5e", null ],
    [ "barcode", "struct_tovar.html#add3cd7c24dc5c28062a5d4c6fe42b04b", null ],
    [ "codec_name", "struct_tovar.html#a0c6ccedf9c913bee32443e26de7a19c3", null ],
    [ "name_of_tovar", "struct_tovar.html#a0558b5260c83faf4e7aa0e832025d590", null ],
    [ "nomer_of_tovar", "struct_tovar.html#a482dd26f52f0f5cf87c19a040d4ccefb", null ],
    [ "price1", "struct_tovar.html#a23aee907302c0340de9dc722444d204b", null ],
    [ "price2", "struct_tovar.html#ac611856fa45875e8c1443477254c1613", null ],
    [ "quantity", "struct_tovar.html#aed46d41d507daa3662368e50c87e046c", null ],
    [ "shablon", "struct_tovar.html#a2b61d47e68345a4ceb2ff00e6c03bc5a", null ]
];