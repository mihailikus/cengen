var structautozakaz__config =
[
    [ "assort", "structautozakaz__config.html#ac290e66a1c36f531e56325ecd9efc37f", null ],
    [ "check_today_sell", "structautozakaz__config.html#a055f0b819d9b69f8d8725652167c2e64", null ],
    [ "datePost", "structautozakaz__config.html#a65b98bfe327d02bea7e31ecdfc8edd21", null ],
    [ "dateStart", "structautozakaz__config.html#aaf37b9b7d17db3362e7b80f442bef51d", null ],
    [ "dateStop", "structautozakaz__config.html#a5dd4731ab76dbf2dbec0f9788bc2a444", null ],
    [ "kol_v_korob", "structautozakaz__config.html#a69684f475925ae62b8f2f86e6661adfb", null ],
    [ "korob_quantum", "structautozakaz__config.html#a91230cc98786ee2cb908f40e29f49786", null ],
    [ "ostat_magazin", "structautozakaz__config.html#a3657264d9cd0ca717633d23934366593", null ],
    [ "ostat_sklad", "structautozakaz__config.html#a6184ac3ce0ff828f7dec25c49801b252", null ]
];