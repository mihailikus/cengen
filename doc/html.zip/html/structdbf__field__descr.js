var structdbf__field__descr =
[
    [ "decimal_count", "structdbf__field__descr.html#ac8a5707d2430c62ccc913e7cffe929c7", null ],
    [ "index_field_flag", "structdbf__field__descr.html#af88ddc41373dad3026466cfcdde34196", null ],
    [ "length", "structdbf__field__descr.html#ab0247121152e565fdf6c414fea5ed51f", null ],
    [ "name", "structdbf__field__descr.html#a2ae1a01fd0931b6030dff960e21fc51a", null ],
    [ "type", "structdbf__field__descr.html#a7af59e7028fd1784ca249fabb411f59f", null ]
];