var structdbf__informer_1_1dbf__one__field =
[
    [ "length", "structdbf__informer_1_1dbf__one__field.html#afc821f5465b8ce01c94e8a649276dc65", null ],
    [ "offset", "structdbf__informer_1_1dbf__one__field.html#ab3d39db3c6416ff8c048833932b2160b", null ]
];