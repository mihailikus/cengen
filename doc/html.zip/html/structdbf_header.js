var structdbf_header =
[
    [ "all_records", "structdbf_header.html#af625a38c637d06689aa99c75497af374", null ],
    [ "codec", "structdbf_header.html#a1514fa8fe8fd942cab943030fb1be16a", null ],
    [ "data_position_in_file", "structdbf_header.html#a0803d31dcbde25f33359a642db84c39e", null ],
    [ "date", "structdbf_header.html#aa87a7e1bf856ae7c9521ccc93afc5431", null ],
    [ "fields", "structdbf_header.html#af7fdd620d22a9dbf985e921053e4ded7", null ],
    [ "incomplete_transac", "structdbf_header.html#a5fbaf8a0ccabc726e0176b79fd6d691c", null ],
    [ "length_of_each_record", "structdbf_header.html#a15f396aef70cd5157a0876cfcf2feb62", null ],
    [ "length_of_header_structure", "structdbf_header.html#a0c4b28279bf63674b754a19d6078d8ce", null ],
    [ "number_of_records", "structdbf_header.html#acc97aaed09659abbe394c55cc931e184", null ]
];